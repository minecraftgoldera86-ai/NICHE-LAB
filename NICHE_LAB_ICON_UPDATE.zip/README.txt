NICHE LAB — ICON UPDATE

This package contains Android launcher icon resources (legacy density PNGs + adaptive icon for Android 8+).

HOW TO APPLY
1. Extract this ZIP.
2. In your Android project, open: app/src/main/res/
3. Copy the folders from this package's app/src/main/res/ into that res folder, merging folders and replacing files with the same names.
4. Make sure app/src/main/AndroidManifest.xml uses android:icon="@mipmap/ic_launcher" and (if present) android:roundIcon="@mipmap/ic_launcher_round".
5. Commit/push the changes to GitHub to trigger the APK build again.

The currently installed app will keep its old icon until you install the newly built APK.
