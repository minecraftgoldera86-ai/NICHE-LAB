# NICHE LAB Mobile (Android)

Projeto Android nativo com uma interface de editor HTML local dentro de WebView.

## O que funciona nesta versão
- Seleção de imagem pela galeria do Android.
- Texto principal e secundário configuráveis.
- Temas e cores neon.
- Efeitos decorativos de raios, brilho e laser estilizado.
- Pré-visualização em canvas.
- Exportação PNG para Pictures/NicheLab e compartilhamento pelo menu Android.
- O processamento da imagem acontece localmente no aparelho.

## Limites da versão 1.0
O gerador de imagens por IA, contas, sincronização em nuvem e galeria com histórico ainda não estão implementados. Os efeitos são gráficos decorativos; o laser não detecta automaticamente os olhos. A versão atual é um editor de memes funcional, não um serviço de geração por IA.

## Gerar o APK
Este ambiente de criação não possui Android SDK/Gradle instalado, então não foi possível compilar nem testar um APK aqui. O repositório inclui GitHub Actions para compilar automaticamente:
1. Extraia o ZIP.
2. Crie um repositório no GitHub e envie os arquivos para a branch `main`.
3. Abra a aba **Actions** e execute **Build NICHE LAB APK** (ou aguarde o build após o push).
4. Baixe o artefato `niche-lab-debug-apk`; dentro dele estará `app-debug.apk`.
5. Transfira o APK para o Android e instale. Talvez seja necessário autorizar a instalação pelo app usado para abrir o arquivo.

Também é possível abrir a pasta no Android Studio e executar `assembleDebug`.
