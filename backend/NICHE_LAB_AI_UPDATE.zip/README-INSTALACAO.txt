# NICHE LAB AI update

## 1. Publicar o servidor
1. Envie as pastas `backend/` e `scripts/`, o arquivo `render.yaml` e o workflow atualizado para a raiz do repositório NICHE-LAB.
2. No Render, crie um **Blueprint** conectado ao repositório. Ele encontrará `render.yaml`.
3. No serviço `niche-lab-ai-api`, abra Environment e adicione `OPENAI_API_KEY` com sua chave secreta da OpenAI. Nunca coloque essa chave no APK ou no GitHub.
4. Faça o deploy e copie a URL pública do serviço (ex.: https://niche-lab-ai-api.onrender.com).

## 2. Gerar o APK
Depois de enviar os arquivos, abra GitHub > Actions > Build NICHE LAB APK > Run workflow (ou aguarde o push terminar). Baixe o artifact `niche-lab-debug-apk`.

## 3. Usar
Abra o NICHE LAB, vá até `NICHE LAB AI STUDIO`, cole a URL do Render e escreva a descrição da arte. A URL fica salva no aparelho.

## Segurança e custos
A chave fica somente como variável de ambiente no Render. O servidor limita a três pedidos por minuto por IP, mas isso não substitui autenticação robusta; não divulgue a URL publicamente. Configure limites de uso e alertas de orçamento na plataforma OpenAI. A geração usa `gpt-image-2.5-flare`, tamanho vertical 1024x1536 e qualidade média. O preço final varia com o uso e com a tabela vigente.
