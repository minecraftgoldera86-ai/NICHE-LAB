from pathlib import Path
p = Path("extracted/niche-lab-android/app/src/main/assets/index.html")
if not p.exists():
    raise SystemExit(f"Não encontrei o HTML do app: {p}")
html = p.read_text(encoding="utf-8")
if "niche-ai-generator" not in html:
    panel = r"""
<style>
#niche-ai-generator{font-family:Arial,sans-serif;margin:24px 12px;padding:20px;border:1px solid #ff7a18;border-radius:18px;background:linear-gradient(145deg,#1a0b05,#090909);color:#fff;box-shadow:0 0 24px #ff6a1833}
#niche-ai-generator h2{margin:0 0 8px;color:#ff7a18;font-size:23px}
#niche-ai-generator p{color:#ccc;font-size:13px;line-height:1.4}
#niche-ai-generator input,#niche-ai-generator textarea{box-sizing:border-box;width:100%;margin:7px 0;padding:13px;border-radius:10px;border:1px solid #63300e;background:#111;color:#fff;font-size:14px}
#niche-ai-generator textarea{min-height:110px;resize:vertical}
#niche-ai-generator button{width:100%;padding:14px;margin-top:9px;border:0;border-radius:12px;background:linear-gradient(90deg,#ff4d00,#ff9b24);color:#160900;font-weight:900;font-size:15px}
#niche-ai-status{font-size:13px;color:#ffb36e;min-height:20px;margin-top:10px}
#niche-ai-result{display:none;width:100%;margin-top:14px;border-radius:12px}
</style>
<section id="niche-ai-generator">
 <h2>⚡ NICHE LAB AI STUDIO</h2>
 <p>Crie artes completas com personagem, iluminação cinematográfica, efeitos e tipografia.</p>
 <input id="niche-ai-url" type="url" placeholder="URL do servidor (Render)">
 <textarea id="niche-ai-prompt" maxlength="1800" placeholder="Ex.: Avatar Roblox de cabelo castanho, olhos brilhando em laranja, raios elétricos e o texto SAUDADEXX DAX JULIAXX"></textarea>
 <button id="niche-ai-button" type="button">GERAR ARTE COM IA</button>
 <div id="niche-ai-status" role="status"></div>
 <img id="niche-ai-result" alt="Arte gerada pelo NICHE LAB">
 <a id="niche-ai-download" style="display:none;color:#ff9b24;margin-top:12px" download="niche-lab-art.png">Salvar imagem</a>
</section>
<script>
(function(){
 const url=document.getElementById('niche-ai-url'), prompt=document.getElementById('niche-ai-prompt');
 const btn=document.getElementById('niche-ai-button'), status=document.getElementById('niche-ai-status');
 const result=document.getElementById('niche-ai-result'), download=document.getElementById('niche-ai-download');
 url.value=localStorage.getItem('nicheAiServer')||'';
 url.addEventListener('change',()=>localStorage.setItem('nicheAiServer',url.value.trim().replace(/\/+$/,'')));
 btn.addEventListener('click',async()=>{
  const base=url.value.trim().replace(/\/+$/,'');
  if(!base){status.textContent='Cole primeiro a URL do servidor Render.';return;}
  if(prompt.value.trim().length<3){status.textContent='Escreva uma ideia para a arte.';return;}
  btn.disabled=true;btn.textContent='CRIANDO SUA ARTE...';status.textContent='A IA está criando a imagem. Pode levar um pouco.';
  result.style.display='none';download.style.display='none';
  try{
   const response=await fetch(base+'/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:prompt.value.trim()})});
   const data=await response.json();
   if(!response.ok)throw new Error(data.detail||'Erro no servidor');
   const src='data:'+(data.mime_type||'image/png')+';base64,'+data.image_base64;
   result.src=src;result.style.display='block';download.href=src;download.style.display='inline-block';
   status.textContent='Arte pronta! 🔥';
  }catch(e){status.textContent='Não foi possível gerar: '+e.message;}
  finally{btn.disabled=false;btn.textContent='GERAR OUTRA ARTE';}
 });
})();
</script>
"""
    html = html.replace("</body>", panel + "\n</body>")
    p.write_text(html, encoding="utf-8")
print("NICHE LAB AI Studio adicionado ao app.")
