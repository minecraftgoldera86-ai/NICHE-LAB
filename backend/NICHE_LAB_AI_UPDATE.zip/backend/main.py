import os
import time
from collections import defaultdict, deque

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="NICHE LAB Image API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

_requests = defaultdict(deque)

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=1800)

@app.get("/")
def health():
    return {"ok": True, "service": "NICHE LAB AI", "message": "API online"}

@app.post("/generate")
def generate(body: GenerateRequest, request: Request):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Servidor sem OPENAI_API_KEY configurada.")

    ip = request.client.host if request.client else "unknown"
    now = time.time()
    recent = _requests[ip]
    while recent and now - recent[0] > 60:
        recent.popleft()
    if len(recent) >= 3:
        raise HTTPException(status_code=429, detail="Limite temporario: espere um minuto.")
    recent.append(now)

    prompt = (
        "Create a polished, high-impact vertical social-media meme poster, 2:3 composition. "
        "Use a dramatic cinematic gaming/Roblox-inspired 3D avatar aesthetic, detailed character "
        "rendering, expressive pose, strong orange/red electric energy, lightning, glowing rim light, "
        "smoke, sparks, deep dark background, professional poster composition, crisp bold typography. "
        "Make the artwork look like a finished premium TikTok meme niche poster, not a screenshot, "
        "not a collage, and not a simple photo with text pasted on top. "
        "Include the user's requested phrase accurately and legibly when provided. "
        "Creative brief: " + body.prompt
    )
    try:
        client = OpenAI(api_key=api_key, timeout=180.0)
        result = client.images.generate(
            model=os.getenv("IMAGE_MODEL", "gpt-image-2.5-flare"),
            prompt=prompt,
            size="1024x1536",
            quality="medium",
            n=1,
        )
        return {"image_base64": result.data[0].b64_json, "mime_type": "image/png"}
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail="Falha ao gerar imagem. Confira saldo, acesso ao modelo e logs do servidor."
        ) from exc
